
  ------------------------------------------------
  
  Thoemmi.CommunityServer.Compression

  Version: 1.1.0.0
  Date:    03-Oct-2005
  Author:  Thomas Freudenberg
  Web:     http://thomasfreudenberg.com/blog/
  
  ------------------------------------------------


Description:
------------

This module reduces the size CS's feeds using HTTP compression. You can find further information on my blog at http://thomasfreudenberg.com/blog/archive/2005/10/03/compress-your-communityserver-feeds.aspx


Installation:
-------------

The installation is pretty easy: Download the ZIP file and extract the DLL's to your bin folder. Then replace the handlers in the httpHandlers section in web.config to point to my classes. Here's a lineup of the corresponding items:

Original blog RSS handler
    CommunityServer.Blogs.Components.WeblogRssHandler, CommunityServer.Blogs
Replacement
    Thoemmi.CommunityServer.Compression.CompressedWeblogRssHandler, Thoemmi.CommunityServer.Compression

Original blog ATOM handler
    CommunityServer.Blogs.Components.WeblogAtomHandler, CommunityServer.Blogs
Replacement
    Thoemmi.CommunityServer.Compression.CompressedWeblogAtomHandler, Thoemmi.CommunityServer.Compression

Original blog comment RSS handler
    CommunityServer.Blogs.Components.WeblogCommentRssHandler, CommunityServer.Blogs
Replacement
    Thoemmi.CommunityServer.Compression.CompressedWeblogCommentRssHandler, Thoemmi.CommunityServer.Compression

Original gallery RSS handler
    CommunityServer.Galleries.Components.GalleryRssHandler, CommunityServer.Galleries
Replacement
    Thoemmi.CommunityServer.Compression.CompressedGalleryRssHandler, Thoemmi.CommunityServer.Compression

Original forum RSS handler
    CommunityServer.Discussions.Components.ForumRssHandler, CommunityServer.Discussions
Replacement
    Thoemmi.CommunityServer.Compression.CompressedForumRssHandler, Thoemmi.CommunityServer.Compression

If you have had a default installation before, the httpHandlers section should now contain following lines:

<add verb="GET" path="blogs/rss.aspx" type="Thoemmi.CommunityServer.Compression.CompressedWeblogRssHandler, Thoemmi.CommunityServer.Compression" />
<add verb="GET" path="blogs/atom.aspx" type="Thoemmi.CommunityServer.Compression.CompressedWeblogAtomHandler, Thoemmi.CommunityServer.Compression" />
<add verb="GET" path="blogs/commentrss.aspx" type="Thoemmi.CommunityServer.Compression.CompressedWeblogCommentRssHandler, Thoemmi.CommunityServer.Compression" />
<add verb="GET" path="photos/rss.aspx" type="Thoemmi.CommunityServer.Compression.CompressedGalleryRssHandler, Thoemmi.CommunityServer.Compression" />
<add verb="GET" path="forums/rss.aspx" type="Thoemmi.CommunityServer.Compression.CompressedForumRssHandler, Thoemmi.CommunityServer.Compression" />

That's it. By default, the feeds are compressed with deflate with normal compression. If you want to change the compression level or switch to gzip compression, have a look at web.config.merge in the ZIP file.


Included 3rd-party modules:
---------------------------
- Ben Lowery's HttpCompressionModule
  http://www.blowery.org/code/HttpCompressionModule.html
- SharpZipLib
  http://www.icsharpcode.net/OpenSource/SharpZipLib/Default.aspx

