using System;
using Dottext.Framework.Components;
using Dottext.Framework.EntryHandling;

namespace Dottext.NoFollow
{
	public class NoFollowFormatHandler : IEntryFactoryHandler
	{
		public NoFollowFormatHandler()
		{}

		public void Configure()
		{}

		public void Process(Entry entry)
		{
			entry.Body = ReformatLinks(entry.Body);
		}

		private string ReformatLinks(string text)
		{
			return text.Replace("<a target=\"_new\" href=\"", "<a target=\"_new\" rel=\"nofollow\" href=\"");
		}
	}
}