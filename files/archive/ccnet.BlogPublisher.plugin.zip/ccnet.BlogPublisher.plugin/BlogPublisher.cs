using System;
using System.IO;
using System.Net;
using System.Xml.XPath;

using CookComputing.MetaWeblog;
using CookComputing.XmlRpc;

using Exortech.NetReflector;

using ThoughtWorks.CruiseControl.Core;
using ThoughtWorks.CruiseControl.Core.Publishers;
using ThoughtWorks.CruiseControl.Core.Util;
using ThoughtWorks.CruiseControl.Remote;

namespace ccnet.BlogPublisher.plugin
{
    [ReflectorType("blog")]
    public class BlogPublisher : XmlRpcClientProtocol, ITask
    {
        private string _url;
        private string _blog;
        private string _username;
        private string _password;
        private string[] _categories;
        private string _proxyHost;
        private int _proxyPort = -1;
        private string _proxyBypassList;
        private bool _proxyBypassOnLocal;
        private string _proxyUsername;
        private string _proxyPassword;
        private string[] _xslFiles;

		#region Public properties

		[ReflectorProperty("url", Required = true)]
        public new string Url
        {
            get { return _url; }
            set { _url = value; }
        }

        [ReflectorProperty("blog", Required = true)]
        public string Blog
        {
            get { return _blog; }
            set { _blog = value; }
        }

        [ReflectorProperty("username", Required = true)]
        public string Username
        {
            get { return _username; }
            set { _username = value; }
        }

        [ReflectorProperty("password", Required = true)]
        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        [ReflectorArray("categories", Required = false)]
        public string[] Categories
        {
            get { return _categories; }
            set { _categories = value; }
        }

        [ReflectorProperty("proxyHost", Required = false)]
        public string ProxyHost
        {
            get { return _proxyHost; }
            set { _proxyHost = value; }
        }

        [ReflectorProperty("proxyPort", Required = false)]
        public int ProxyPort
        {
            get { return _proxyPort; }
            set { _proxyPort = value; }
        }

        [ReflectorProperty("proxyBypassList", Required = false)]
        public string ProxyBypassList
        {
            get { return _proxyBypassList; }
            set { _proxyBypassList = value; }
        }

        [ReflectorProperty("proxyBypassOnLocal", Required = false)]
        public bool ProxyBypassOnLocal
        {
            get { return _proxyBypassOnLocal; }
            set { _proxyBypassOnLocal = value; }
        }

        [ReflectorProperty("proxyUsername", Required = false)]
        public string ProxyUsername
        {
            get { return _proxyUsername; }
            set { _proxyUsername = value; }
        }

        [ReflectorProperty("proxyPassword", Required = false)]
        public string ProxyPassword
        {
            get { return _proxyPassword; }
            set { _proxyPassword = value; }
        }

        [ReflectorArray("xslFiles", Required = false)]
        public string[] XslFiles
        {
            get { return _xslFiles; }
            set { _xslFiles = value; }
		}

		#endregion

		public void Run(IIntegrationResult result)
        {
            if (result.Status == IntegrationStatus.Unknown)
                return;

            PrepareXmlRpc();

            string subject = CreateSubject(result);
            string body;
            try
            {
                body = CreateMessage(result);
            }
            catch (Exception e)
            {
                string message = "Unable to create blog content: " + e;
                Log.Error(message);
                return;
            }

            Post post = new Post();
            post.dateCreated = result.StartTime;
            post.description = body;
            post.title = subject;
            post.categories = _categories;
            newPost(_blog, _username, _password, post, true);
            
            Log.Info("Integration results published on blog \"" + _blog + "\"");
        }

        private void PrepareXmlRpc()
        {
            NonStandard = XmlRpcNonStandard.All;
            base.Url = _url;
			if (!String.IsNullOrEmpty(_proxyHost) && _proxyPort > 0)
            {
                WebProxy proxy = new WebProxy(_proxyHost, _proxyPort);

                if (!String.IsNullOrEmpty(_proxyBypassList))
                    proxy.BypassList = _proxyBypassList.Split(',');
                proxy.BypassProxyOnLocal = _proxyBypassOnLocal;

				if (!String.IsNullOrEmpty(_proxyUsername) && !String.IsNullOrEmpty(_proxyPassword))
                    proxy.Credentials = new NetworkCredential(_proxyUsername, _proxyPassword);

                Proxy = proxy;
            }
        }

        [XmlRpcMethod("metaWeblog.newPost", Description = "Makes a new post to a designated blog using the MetaWeblog API. Returns postid as a string.")]
        public string newPost(string blogid, string username, string password, Post post, bool publish)
        {
            return (string)Invoke("newPost", new object[] { blogid, username, password, post, publish });
        }
        
        private string CreateMessage(IIntegrationResult result)
        {
            StringWriter buffer = new StringWriter();
            using (XmlIntegrationResultWriter integrationWriter = new XmlIntegrationResultWriter(buffer))
            {
                integrationWriter.Write(result);
            }

            XPathDocument xml = new XPathDocument(new StringReader(buffer.ToString()));
            
            BuildLogTransformer buildLogTransformer = new BuildLogTransformer();
            if (_xslFiles == null || _xslFiles.Length == 0)
                return buildLogTransformer.TransformResultsWithAllStyleSheets(xml);
            else
                return buildLogTransformer.TransformResults(_xslFiles, xml);
        }
        
        private static string CreateSubject(IIntegrationResult result)
        {
            if (result.Status == IntegrationStatus.Success)
            {
                if (result.LastIntegrationStatus != result.Status)
                {
                    return String.Format("{0} Build Fixed: Build {1}", result.ProjectName, result.Label);
                }
                else
                {
                    return String.Format("{0} Build Successful: Build {1}", result.ProjectName, result.Label);
                }
            }
            else
            {
                return String.Format("{0} Build Failed", result.ProjectName);
            }
        }
    }
}
